package com.kayali_developer.smartphonecafe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LoginActivity extends AppCompatActivity {
    @BindView(R.id.etv_email)
    EditText etvEmail;
    @BindView(R.id.etv_password)
    EditText etvPassword;
    @BindView(R.id.btn_login)
    Button btnLogin;
    @BindView(R.id.snack_bar_layout)
    CoordinatorLayout snackBarLayout;
    private FirebaseAuth mAuth;
    private Snackbar mSnackbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();


    }


    @Override
    protected void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null){
            updateUI(currentUser);
        }else{
            startSignUpActivity();
        }

    }

    private void startSignUpActivity() {
        Intent signUpIntent = new Intent(LoginActivity.this, SignUpActivity.class);
        if (signUpIntent.resolveActivity(getPackageManager()) != null){
            startActivity(signUpIntent);
        }
    }

    private void updateUI(FirebaseUser currentUser) {
        initializeSnackBar(currentUser.getEmail(), Snackbar.LENGTH_SHORT);
    }

    private void signIn() {
        String email = null;
        try {
            email = etvEmail.getText().toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        String password = null;
        try {
            password = etvPassword.getText().toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (password == null || TextUtils.isEmpty(password) || password.length() < 10) {
            initializeSnackBar(getString(R.string.valid_email_warning), Snackbar.LENGTH_SHORT);
        }

        if (email == null || TextUtils.isEmpty(email) || !email.contains("@")) {
            initializeSnackBar(getString(R.string.valid_email_warning), Snackbar.LENGTH_SHORT);
        }

        if (password != null && !TextUtils.isEmpty(password) && password.length() >= 10 &&
                email != null && !TextUtils.isEmpty(email) && !email.contains("@")) {

            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                FirebaseUser user = mAuth.getCurrentUser();
                                updateUI(user);
                            } else {
                                // If sign in fails, display a message to the user.
                                Toast.makeText(LoginActivity.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();
                                updateUI(null);
                            }

                        }
                    });
        }
    }

    private void initializeSnackBar(String text, int duration) {
        mSnackbar = Snackbar
                .make(snackBarLayout, text, duration);
        View sbView = mSnackbar.getView();
        TextView textView = sbView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        textView.setTextColor(Color.WHITE);
    }


    @OnClick(R.id.btn_login)
    public void onViewClicked() {
        signIn();
    }
}
